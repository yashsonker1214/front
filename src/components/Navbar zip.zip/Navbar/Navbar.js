import React, { useState } from "react";
import { Link } from "react-router-dom"; // Import Link for navigation
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import Menu from "@mui/material/Menu";
import Container from "@mui/material/Container";
import AccountCircle from "@mui/icons-material/AccountCircle";
import SearchIcon from "@mui/icons-material/Search";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
import Tooltip from "@mui/material/Tooltip";
import MenuItem from "@mui/material/MenuItem";
import InputBase from "@mui/material/InputBase";
import { styled } from "@mui/material/styles";
import "./Navbar.css";
import MenuIcon from "@mui/icons-material/Menu";
import { Divider } from "@mui/material";

const settings = ["Profile", "Account", "Dashboard", "Logout"];
const pages = [
  {
    name: "Flour",
    path: "/flour",
    items: [
      "Wheat Flour",
      "Maize(corn) Flour ",
      "Rye Flour ",
      "Brown Rice Flour",
      "White Flour",
      "Rice Flour",
      "Millet Flour",
      "Oat Flour",
      "Soga Flour",
      "Tamarind Flour",
      "Singhada Flour",
      "Mango Flour",
      "Samolina",
      "Gram Flour",
      "Soyabean Flour",
      "Ragi Flour",
      "Sorghum Flour",
      "Almond Flour ",
      "BuckWheat Flour ",
      "Durum Wheat Flour",
    ],
  },
  {
    name: "Powdered Spices",
    path: "/powderedspices",
    items: [
      "Black Pepper  ",
      " Red Chilly ",
      "Coriander  ",
      "Cumin",
      "Dry Ginger",
      "Dry Mango Powder",
      "Garam Masala",
      "Garlic Powder",
      "Hing",
      "Mixed Spice & Seas",
      "Onion Powder",
      "Paprika",
      "Turmeric",
      "White Pepper",
      "Fennel Seeds",
      "Chinnamon",
      "Mace",
      "Green Cardamon",
      "Fenugreek",
      "Musterd",
      "Fennel Seeds",
    ],
  },
  {
    name: "Spices-Whole",
    path: "/spices",
    items: [
      " Whole Spices",
      "Black Pepper ",
      "Dried Red Chilly ",
      "Cloves",
      "NUtmeg",
      "Mace",
      "Large Cardamom",
      "Green Cardamon",
      "Cumin Seeds",
      "Star Anise",
      "Dried Ginger",
      "Dried Turmeric",
      "Fenugreek Seed",
      "Dill Seed",
      "Ajwan Seed",
      "Musterd Seed",
      "Ajwain",
      "Tej Pata(Bay Leaves)",
      "Chilli Flakes",
      "Coriander Seeds",
    ],
  },
  {
    name: "Basmati Rice",
    path: "/basmati",
    items: [
      "1121 Golden Sella",
      "1121 Steam Sella",
      "PR11 Golden Sella",
      "PR11 Steam Sella",
      "PR11 Creamy Sella",
      "Sharbati",
      "Sugandha",
      "Pusa",
      "1509Basmati Rice",
    ],
  },
  {
    name: "Non-Basmati",
    path: "/nonBasmati",
    items: [
      "IR 64 Parboiled ",
      "IR64 Raw",
      "Long Grain Raw",
      "Long Grain Parboiled",
      "100%Broken Rice",
      "Swarna Raw",
      "Sawrna Parboiled",
      "Sona Masuri Raw",
      "Sona Masuri Parboiled",
    ],
  },
  {
    name: "Rice-other",
    path: "/riceother",
    items: [
      "Thai Long Grain Raw",
      "Thai Long Grain",
      "IRRI 6",
      "IRRI 9",
      "Super Karnel Basmati Rice",
      "PK 386",
      "Japanica",
      "Calros",
    ],
  },

  {
    name: "Grains",
    path: "/grains",
    items: [
      " Wheat",
      "Maize ",
      "Yellow Corn ",
      "Millet",
      "Bajra",
      "Sorghum",
      "Ragi",
      "Oats",
      "BuckWheat",
      "Durum Wheat",
    ],
  },

  {
    name: "Oil Seed",
    path: "/oilseed",
    items: [
      "Rapeseed",
      " Soyabean Seeds",
      "Sunflower Seeds ",
      "Corn Seeds",
      "Seasme Seeds",
      "Cotton Seeds",
      "Flaxseed",
      "Peanut",
      "Palm Oil",
      "Coconut ",
    ],
  },

  {
    name: "Pulses",
    path: "/pulses",
    items: [
      "ChickPeas",
      "Mung Bean ",
      "Lenthil ",
      "Pigeon Pea",
      "Kidney Beans",
      "Urad Dal",
      "Lima Beans",
      "Black Eyed Peas",
      "Horse Gram",
      "Moth Beans",
      "Green Beans",
      "Split Pea",
      "Split Pigeon Peas",
      "Split Pea Gram",
      "Bambara Beans",
      "Lupine",
      "Cow Peas",
    ],
  },
  {
    name: "Vegetables",
    path: "/vegetables",
    items: ["Red Onion  ", "White Onion ", "Potato "],
  },
];
const Search = styled("div")(({ theme }) => ({
  borderRadius: 0,
  border: "1px solid #febd2f",
  backgroundColor: "#173334",
  display: "flex",
  alignItems: "center",
  height: "50px",
  width: "100%",
  left: "2rem",
  marginLeft: "10rem",
  [theme.breakpoints.up("sm")]: {
    marginLeft: theme.spacing(3),
    width: "auto",
  },
  "&:hover": {
    backgroundColor: "#173334",
  },
}));

const SearchIconWrapper = styled("div")(({ theme }) => ({
  height: "100%",
  pointerEvents: "none",
  display: "flex",
  alignItems: "center",
}));

const StyledInputBase = styled(InputBase)(({ theme }) => ({
  color: "inherit",
  "& .MuiInputBase-input": {
    padding: 5,
    paddingLeft: "2rem",
    transition: theme.transitions.create("width"),
    width: "100%",
    [theme.breakpoints.up("md")]: {
      width: "20ch",
    },
  },
}));

function ResponsiveAppBar() {
  const [anchorElNav, setAnchorElNav] = React.useState(null);
  const [anchorElUser, setAnchorElUser] = React.useState(null);
  const [openDropdown, setOpenDropdown] = React.useState(null);

  const [isDropdownVisible, setDropdownVisible] = useState(false);

  // const handleMouseEnter = () => {
  //   setDropdownVisible(true);
  // };

  // const handleMouseLeave = () => {
  //   setDropdownVisible(false);
  // };
  // Function to handle mouse enter and leave for both parent and dropdown
  const handleMouseEnter = (index) => setOpenDropdown(index);
  const handleMouseLeave = () => setOpenDropdown(null);

  const handleOpenNavMenu = (event) => {
    setAnchorElNav(event.currentTarget);
  };

  const handleCloseNavMenu = () => {
    setAnchorElNav(null);
  };

  const handleOpenUserMenu = (event) => {
    setAnchorElUser(event.currentTarget);
  };

  const handleCloseUserMenu = () => {
    setAnchorElUser(null);
  };

  return (
    <>
      <AppBar position="static" sx={{ backgroundColor: "#173334", pb: 1 }}>
        <p
          className="marquee-text"
          style={{ backgroundColor: "#173334", color: "#febd2f" }}
        >
          "Our website is under maintenance. We’re making improvements and will
          be back shortly. Thank you for your patience."
        </p>

        {/* first  */}
        <Container maxWidth="xl">
          <Toolbar disableGutters>
            {/* Logo */}
            <Typography
              variant="h6"
              noWrap
              component={Link} // Use Link instead of 'a'
              to="/"
              sx={{
                mr: 2,
                pr: 10,
                display: { xs: "none", md: "flex" },
                fontFamily: "monospace",
                fontWeight: 700,
                letterSpacing: ".1rem",
                color: "#febd2f",
                textDecoration: "none",
              }}
            >
              TheAgriGoods
            </Typography>

            {/* Search Field */}
            <Search>
              <StyledInputBase
                placeholder="Search…"
                inputProps={{ "aria-label": "search" }}
                sx={{
                  color: "#febd2f",
                }}
              />
              <SearchIconWrapper>
                <SearchIcon
                  sx={{
                    color: "#173334",
                    bgcolor: "#febd2f",
                    height: "100%",
                    ml: 5,
                    width: "2rem",
                  }}
                />
              </SearchIconWrapper>
            </Search>

            <Box sx={{ flexGrow: 1 }} />

            {/* Cart Icon and Text */}
            <Box
              sx={{ display: "flex", alignItems: "center", color: "#febd2f" }}
            >
              <Tooltip title="My Cart">
                <IconButton sx={{ p: 0, color: "#febd2f" }}>
                  <ShoppingCartIcon />
                </IconButton>
              </Tooltip>
              <Typography variant="body1" sx={{ mr: 5, ml: 1 }}>
                My Cart
              </Typography>

              {/* Profile Icon and Text */}
              <Tooltip title="Open settings">
                <IconButton
                  onClick={handleOpenUserMenu}
                  sx={{ p: 0, color: "#febd2f" }}
                >
                  <AccountCircle />
                </IconButton>
              </Tooltip>
              <Typography variant="body1" sx={{ mr: 5, ml: 1 }}>
                My Profile
              </Typography>

              {/* Menu */}
              <Menu
                sx={{ mt: "45px" }}
                id="menu-appbar"
                anchorEl={anchorElUser}
                anchorOrigin={{
                  vertical: "top",
                  horizontal: "right",
                }}
                keepMounted
                transformOrigin={{
                  vertical: "top",
                  horizontal: "right",
                }}
                open={Boolean(anchorElUser)}
                onClose={handleCloseUserMenu}
              >
                {settings.map((setting) => (
                  <MenuItem key={setting} onClick={handleCloseUserMenu}>
                    <Typography sx={{ textAlign: "center" }}>
                      {setting}
                    </Typography>
                  </MenuItem>
                ))}
              </Menu>
            </Box>
          </Toolbar>
        </Container>

        {/* Divider with full width */}
        <Divider sx={{ color: "#febd2f", my: 1, width: "100%", mx: 0 }} />

        <Container maxWidth="lg">
          <Box sx={{ flexGrow: 1 }} />

          {/* Mobile Menu */}
          <Box sx={{ flexGrow: 1, display: { xs: "flex", md: "none" } }}>
            <IconButton
              size="small"
              aria-label="menu"
              aria-controls="menu-appbar"
              aria-haspopup="true"
              onClick={handleOpenNavMenu}
              color="inherit"
            >
              <MenuIcon />
            </IconButton>

            <Menu
              id="menu-appbar"
              anchorEl={anchorElNav}
              anchorOrigin={{
                vertical: "bottom",
                horizontal: "left",
              }}
              keepMounted
              transformOrigin={{
                vertical: "top",
                horizontal: "left",
              }}
              open={Boolean(anchorElNav)}
              onClose={handleCloseNavMenu}
              sx={{
                display: { xs: "block", md: "none" },
              }}
            >
              {pages.map((page) => (
                <MenuItem key={page.name} onClick={handleCloseNavMenu}>
                  <Link to={page.path} style={{ textDecoration: "none" }}>
                    <Typography sx={{ textAlign: "center", color: "#febd2f" }}>
                      {page.name}
                    </Typography>
                  </Link>
                  {/* Submenu Items */}
                  <Box
                    sx={{
                      display: "none",
                      position: "absolute",
                      left: "100%",
                      top: "0",
                      backgroundColor: "#173334",
                      padding: "10px",
                    }}
                  >
                    {page.items.map((item) => (
                      <Link
                        to={page.path}
                        style={{ textDecoration: "none" }}
                        key={item}
                      >
                        <MenuItem
                          sx={{ color: "#febd2f", textAlign: "center" }}
                        >
                          {item}
                        </MenuItem>
                      </Link>
                    ))}
                  </Box>
                </MenuItem>
              ))}
            </Menu>
          </Box>

          {/* Desktop Menu with Dropdown on Hover */}
          <Box
            sx={{ display: { xs: "none", md: "flex" }, position: "relative" }}
          >
            <Box
              sx={{
                display: "flex",
                gap: "2.5rem",
                alignItems: "left",
                position: "relative",
              }}
            >
              {pages.map((page, index) => (
                <Box
                  key={page.name}
                  sx={{
                    display: "flex",
                    flexDirection: "column",

                    justifyContent: "left",
                    alignItems: "left",
                    position: "relative",
                    "&:hover > .dropdown-menu": {
                      display: "block", // Show the dropdown on hover
                    },
                  }}
                  onMouseEnter={() => handleMouseEnter(index)}
                  onMouseLeave={handleMouseLeave}
                >
                  <Typography
                    sx={{
                      color: "#febd2f",
                      cursor: "pointer",
                      "&:hover": {
                        color: "#febd2f",
                      },
                    }}
                  >
                    {page.name}
                  </Typography>

                  {/* Dropdown Menu */}
                  <Box
                    className="dropdown-menu"
                    sx={{
                      position: "absolute",
                      top: "30px",
                      left: "0",
                      backgroundColor: "#fff",
                      color: "#173334",
                      padding: "10px",
                      paddingRight: "4rem",
                      borderRadius: "0px",
                      boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.2)",
                      width: "300px",
                      overflowY: "auto",
                      display: openDropdown === index ? "block" : "none",
                      transition: "all 0.3s ease",
                    }}
                  >
                    {" "}
                    <div className="App">
                      <header className="App-header">
                        <div
                          className="menu"
                          onMouseEnter={handleMouseEnter}
                          onMouseLeave={handleMouseLeave}
                        >
                          <button>Dropdown Menu</button>
                          {/* <DropdownMenu /> */}
                          {isDropdownVisible && (
                            <div className="dropdown-menu">
                              <ul>
                                <li>Menu 1</li>
                                <li>Menu 2</li>
                                <li>Menu 3</li>
                              </ul>
                            </div>
                          )}
                        </div>
                      </header>
                    </div>
                    {page.items.map((item) => (
                      <Link
                        to={page.path}
                        style={{ textDecoration: "none" }}
                        key={item}
                      >
                        <Typography
                          sx={{
                            color: "#173334",
                            display: "flex",
                            justifyContent: "space-between",
                            textAlign: "center",
                            padding: "12px",
                            transition:
                              "background-color 0.3s ease, transform 0.2s ease",
                            "&:hover": {
                              color: "#febd2f",
                              transform: "scale(1.05)",
                            },
                          }}
                        >
                          {item}
                        </Typography>
                      </Link>
                    ))}
                  </Box>
                </Box>
              ))}
            </Box>
          </Box>
        </Container>
      </AppBar>
    </>
  );
}

export default ResponsiveAppBar;
