import React from 'react'

function Category() {
  return (
    <div>
      
    </div>
  )
}

export default Category
