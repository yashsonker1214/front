import React from 'react'

function Allproducts() {
  return (
    <div>
      
    </div>
  )
}

export default Allproducts
